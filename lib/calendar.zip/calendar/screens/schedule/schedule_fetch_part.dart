part of '../schedule_screen.dart';

extension _FetchAndCompute on _ScheduleScreenState {
  Future<void> _loadCalendar() async {
    try {
      final res = await _futureCalendar;
      _events = res.data;
      _recomputeMonthBadges();
      _computeGlobalBounds();
    } catch (e, st) {
      debugPrint('fetch error: $e\n$st');
    }
    setState(() {});
  }

  Future<void> _reFetch({bool recomputeMonth = false}) async {
    if (_loading) return;
    _loading = true;
    setState(() {});

    try {
      final res = await fetchCalendarSingleList(null, true);
      _events = res.data;

      if (recomputeMonth || _isMonthView) {
        _recomputeMonthBadges();
        _computeGlobalBounds();
      } else {
        // ✅ 리스트 모드면 캐시 재계산 (주간은 build에서 즉시 반영됨)
        if (_mode == SelectionMode.list) {
          if (_days.isEmpty) {
            _initListWindow(); // 최초 진입 케이스 커버
          } else {
            _byDay = occurrencesByDay(events: _events, days: _days);
            // 필요하면 스크롤 위치 보존
            _anchorToPreserve ??= _focusDayForList;
          }
        }
        setState(() {});
      }
    } catch (e, st) {
      debugPrint('fetch error: $e\n$st');
    } finally {
      _loading = false;
      setState(() {});
    }
  }


  void _recomputeMonthBadges() {
    _eventCountByDay = computeBadgeCounts(
      displayMonth: _displayMonth,
      events: _events,
    );
    debugLogMonthBadges(displayMonth: _displayMonth, events: _events);
    setState(() {});
  }

  void _computeGlobalBounds() {
    if (_events.isEmpty) {
      final today = _dOnly(DateTime.now());
      _globalMin = today;
      _globalMax = today;
      return;
    }

    DateTime minD = DateTime(9999);
    DateTime maxD = DateTime(0);

    for (final e in _events) {
      final s = _parseLocal(e.start);
      final t = _parseLocal(e.end);
      final sd = _dOnly(s);
      final td = _dOnly(t);
      if (sd.isBefore(minD)) minD = sd;
      if (td.isAfter(maxD)) maxD = td;
    }
    _globalMin = minD;
    _globalMax = maxD;
  }
}
