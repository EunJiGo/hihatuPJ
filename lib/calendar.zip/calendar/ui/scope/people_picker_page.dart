// lib/calendar/ui/scope/people_picker_page.dart
import 'package:flutter/material.dart';
import '../../domain/employee.dart';

class PeoplePickerPage extends StatefulWidget {
  const PeoplePickerPage({
    super.key,
    required this.employees,
    required this.initiallySelected,
  });

  /// 전체 사원 마스터
  final List<Employee> employees;

  /// 이미 선택되어 있는 employee_id 집합
  final Set<int> initiallySelected;

  @override
  State<PeoplePickerPage> createState() => _PeoplePickerPageState();
}

class _PeoplePickerPageState extends State<PeoplePickerPage> {
  final _query = TextEditingController();

  /// 부서명 -> 펼침 여부
  final Map<String, bool> _expanded = {};

  /// 선택된 employee_id 집합
  late final Set<int> _checked;

  /// 부서명 목록 (정렬)
  late final List<String> _departments;

  /// 부서별 인원 맵 (부서 내 중복 제거)
  late final Map<String, List<Employee>> _byDept;

  static const String _kNoDept = '（部署なし）';

  @override
  void initState() {
    super.initState();
    _checked = {...widget.initiallySelected};
    _buildGroups();
  }

  void _buildGroups() {
    // 부서 목록 수집
    final deptSet = <String>{};
    for (final e in widget.employees) {
      if (e.departments.isEmpty) {
        deptSet.add(_kNoDept);
      } else {
        deptSet.addAll(e.departments);
      }
    }
    final depts = deptSet.toList()..sort();
    _departments = depts;

    // 부서별 인원 맵
    final map = <String, List<Employee>>{};
    for (final d in _departments) {
      map[d] = [];
    }
    for (final e in widget.employees) {
      final ds = e.departments.isEmpty ? <String>[_kNoDept] : e.departments;
      for (final d in ds) {
        final list = map[d]!;
        // 같은 부서에 같은 사람이 중복 추가되지 않도록 guard
        if (!list.any((x) => x.id == e.id)) list.add(e);
      }
    }
    // 이름 기준 정렬
    for (final d in _departments) {
      map[d]!.sort((a, b) => (a.name).compareTo(b.name));
    }
    _byDept = map;

    // 펼침 상태 초기화
    for (final d in _departments) {
      _expanded[d] = false;
    }
  }

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  bool _matches(Employee e, String q) {
    if (q.isEmpty) return true;
    final lower = q.toLowerCase();
    if (e.name.toLowerCase().contains(lower)) return true;
    if (e.kana.toLowerCase().contains(lower)) return true;
    for (final t in (e.searchTokens ?? const [])) {
      if (t.toLowerCase().contains(lower)) return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    final q = _query.text.trim();
    final searching = q.isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: const Text('社員を追加'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop<Set<int>>(context, _checked);
            },
            child: const Text(
              '追加',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // 검색바
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            child: TextField(
              controller: _query,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                hintText: '検索（名前 / カナ / ルール）',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.search),
                isDense: true,
              ),
            ),
          ),
          // 목록
          Expanded(
            child: ListView.builder(
              itemCount: _departments.length,
              itemBuilder: (context, index) {
                final dept = _departments[index];
                final all = _byDept[dept] ?? const <Employee>[];
                final list = all.where((e) => _matches(e, q)).toList();

                // 검색 중이면 결과 없는 그룹은 숨김
                if (searching && list.isEmpty) {
                  return const SizedBox.shrink();
                }

                final open = searching ? true : (_expanded[dept] ?? false);

                return Column(
                  children: [
                    _groupTile(
                      deptName: dept,
                      open: open,
                      onToggle: searching
                          ? null
                          : () => setState(() => _expanded[dept] = !open),
                    ),
                    if (open)
                      ...list.map(_personTile),
                    const Divider(height: 0),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _groupTile({
    required String deptName,
    required bool open,
    VoidCallback? onToggle,
  }) {
    return ListTile(
      dense: true,
      title: Text(
        deptName,
        style: const TextStyle(fontWeight: FontWeight.w700),
      ),
      trailing: onToggle == null
          ? null
          : Icon(open ? Icons.expand_less : Icons.expand_more),
      onTap: onToggle,
    );
  }

  Widget _personTile(Employee e) {
    final checked = _checked.contains(e.id);
    return CheckboxListTile(
      value: checked,
      dense: true,
      title: Text(e.name),
      subtitle: e.kana.isNotEmpty ? Text(e.kana, style: const TextStyle(fontSize: 12)) : null,
      onChanged: (v) => setState(() {
        if (v == true) {
          _checked.add(e.id);
        } else {
          _checked.remove(e.id);
        }
      }),
    );
  }
}
