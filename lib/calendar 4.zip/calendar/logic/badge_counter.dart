// 날짜별 스케줄 카운트 계산해서 월간 캘린더에 파란색 점 보여줄 수 있도록 하는 함수
import '../domain/calendar_single.dart';
import 'time_utils.dart';
import 'recurrence.dart';

Map<DateTime, int> computeBadgeCounts({
  required DateTime displayMonth,
  required List<CalendarSingle> events,
}) {
  final windowStart = DateTime(displayMonth.year, displayMonth.month, 1);
  final windowEnd   = DateTime(displayMonth.year, displayMonth.month,
      daysInMonth(displayMonth.year, displayMonth.month), 23, 59, 59);

  // 월의1일부터 월의 마지막일까지의 해당되는 Occurrence 객체 리스트
  final occ = expandOccurrencesForWindow(events, windowStart: windowStart, windowEnd: windowEnd);

  final map = <DateTime, int>{};

  for (final o in occ) {
    for (final d in eachLocalDateCovered(o.startLocal, o.endLocal)) { // [2025-09-04, 2025-09-05]
      if (d.year == displayMonth.year && d.month == displayMonth.month) {
        final key = DateTime(d.year, d.month, d.day);
        map[key] = (map[key] ?? 0) + 1;
      }
    }
  }
  return map;
}

/// 선택한 설비(equipmentIds)가 1개라도 포함된 이벤트가 있는 날짜를 true로 마킹해서
/// 월간 캘린더에서 "회색 동그라미" 표시용으로 쓴다.
Map<DateTime, bool> computeEquipmentBadges({
  required DateTime displayMonth,       // 보이는 달(보통 1일로 정규화)
  required List<CalendarSingle> events, // _events 전체(사람/설비 합쳐진 리스트)
  required Set<int> equipmentIds,       // _selectedEquipIds
}) {
  if (equipmentIds.isEmpty) return const {};

  final windowStart = DateTime(displayMonth.year, displayMonth.month, 1);
  final windowEnd   = DateTime(
    displayMonth.year,
    displayMonth.month,
    daysInMonth(displayMonth.year, displayMonth.month),
    23, 59, 59,
  );

  // 해당 월 범위의 발생 인스턴스 확장
  final occ = expandOccurrencesForWindow(
    events,
    windowStart: windowStart,
    windowEnd: windowEnd,
  );

  bool _occHasAnyEquipment(Occurrence o) {
    try {
      for (final e in o.src.equipments) {
        final raw = e['equipment_id'] ?? e['id']; // 서버가 주는 키 케이스 모두 대응
        int? id;
        if (raw is int) id = raw;
        if (raw is String) id = int.tryParse(raw);
        if (id != null && equipmentIds.contains(id)) return true;
      }
    } catch (_) {}
    return false;
  }

  final map = <DateTime, bool>{};

  for (final o in occ) {
    if (!_occHasAnyEquipment(o)) continue;

    // 이벤트가 걸치는 모든 날짜를 day-only 키로 마킹
    for (final d in eachLocalDateCovered(o.startLocal, o.endLocal)) {
      if (d.year == displayMonth.year && d.month == displayMonth.month) {
        final key = DateTime(d.year, d.month, d.day); // dateOnly 키
        map[key] = true;
      }
    }
  }
  return map;
}




