import 'package:flutter/material.dart';
import '../types.dart';
import '../ui/month_grid.dart';

/// 월간: 제스처 + MonthGrid (동작 동일)
class MonthBody extends StatelessWidget {
  const MonthBody({
    super.key,
    required this.displayMonth,
    required this.eventCountByDay,
    required this.onTapDate,
    required this.onShiftMonth,
    this.badgesByDay,
  });

  final DateTime displayMonth;
  final Map<DateTime, int> eventCountByDay;
  final Future<void> Function(DateTime) onTapDate;
  /// 음수: 이전 달, 양수: 다음 달
  final void Function(int delta) onShiftMonth;
  final Map<DateTime, MonthBadge>? badgesByDay;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onVerticalDragEnd: (details) {
        final v = details.primaryVelocity ?? 0;
        if (v.abs() < 80) return; // 기존 임계값 그대로
        v < 0 ? onShiftMonth(1) : onShiftMonth(-1);
      },
      child: MonthGrid(
        displayMonth: displayMonth,
        eventCountByDay: eventCountByDay,
        badgesByDay: badgesByDay,
        onTapDate: onTapDate,
      ),
    );
  }
}
