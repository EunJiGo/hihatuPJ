// 날짜별 스케줄 카운트 계산해서 월간 캘린더에 파란색 점 보여줄 수 있도록 하는 함수
import '../domain/calendar_single.dart';
import 'time_utils.dart';
import 'recurrence.dart';

Map<DateTime, int> computeBadgeCounts({
  required DateTime displayMonth,
  required List<CalendarSingle> events,
}) {
  final windowStart = DateTime(displayMonth.year, displayMonth.month, 1);
  final windowEnd   = DateTime(displayMonth.year, displayMonth.month,
      daysInMonth(displayMonth.year, displayMonth.month), 23, 59, 59);

  // 월의1일부터 월의 마지막일까지의 해당되는 Occurrence 객체 리스트
  final occ = expandOccurrencesForWindow(events, windowStart: windowStart, windowEnd: windowEnd);

  final map = <DateTime, int>{};

  for (final o in occ) {
    for (final d in eachLocalDateCovered(o.startLocal, o.endLocal)) { // [2025-09-04, 2025-09-05]
      if (d.year == displayMonth.year && d.month == displayMonth.month) {
        final key = DateTime(d.year, d.month, d.day);
        map[key] = (map[key] ?? 0) + 1;
      }
    }
  }
  return map;
}
