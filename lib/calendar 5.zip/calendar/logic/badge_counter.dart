// 날짜별 스케줄 카운트 계산해서 월간 캘린더에 파란색 점 보여줄 수 있도록 하는 함수
import '../domain/calendar_single.dart';
import 'time_utils.dart';
import 'recurrence.dart';

Map<DateTime, int> computeBadgeCounts({
  required DateTime displayMonth,
  required List<CalendarSingle> events,
}) {
  final windowStart = DateTime(displayMonth.year, displayMonth.month, 1);
  final windowEnd   = DateTime(displayMonth.year, displayMonth.month,
      daysInMonth(displayMonth.year, displayMonth.month), 23, 59, 59);

  // 월의1일부터 월의 마지막일까지의 해당되는 Occurrence 객체 리스트
  final occ = expandOccurrencesForWindow(events, windowStart: windowStart, windowEnd: windowEnd);

  final map = <DateTime, int>{};

  for (final o in occ) {
    for (final d in eachLocalDateCovered(o.startLocal, o.endLocal)) { // [2025-09-04, 2025-09-05]
      if (d.year == displayMonth.year && d.month == displayMonth.month) {
        final key = DateTime(d.year, d.month, d.day);
        map[key] = (map[key] ?? 0) + 1;
      }
    }
  }
  return map;
}

/// 선택한 설비(equipmentIds)가 1개라도 포함된 이벤트가 있는 날짜를 true로 마킹해서
/// 월간 캘린더에서 "회색 동그라미" 표시용으로 쓴다.
Map<DateTime, int> computeEquipmentBadges({
  required DateTime displayMonth,       // 1일 정규화된 달
  required List<CalendarSingle> events, // 사람/설비 합쳐진 리스트(_events)
  required Set<int> equipmentIds,       // 선택된 설비 ID들(_selectedEquipIds)
}) {
  if (equipmentIds.isEmpty) return <DateTime, int>{};

  final windowStart = DateTime(displayMonth.year, displayMonth.month, 1);
  final windowEnd   = DateTime(
    displayMonth.year,
    displayMonth.month,
    daysInMonth(displayMonth.year, displayMonth.month),
    23, 59, 59,
  );

  // 월 범위로 Occurrence 확장 (멀티데이/반복 고려)
  final occ = expandOccurrencesForWindow(
    events,
    windowStart: windowStart,
    windowEnd: windowEnd,
  );

  bool _occHasAnySelectedEquipment(Occurrence o) {
    for (final e in o.src.equipments) {
      final raw = e['equipment_id'] ?? e['id'];
      int? id;
      if (raw is int) id = raw;
      if (raw is String) id = int.tryParse(raw);
      if (id != null && equipmentIds.contains(id)) return true;
    }
    return false;
  }

  final map = <DateTime, int>{};

  for (final o in occ) {
    if (!_occHasAnySelectedEquipment(o)) continue;

    // 이 오커런스가 덮는 날짜마다 +1
    for (final d in eachLocalDateCovered(o.startLocal, o.endLocal)) {
      if (d.year == displayMonth.year && d.month == displayMonth.month) {
        final key = DateTime(d.year, d.month, d.day); // dateOnly 키
        map[key] = (map[key] ?? 0) + 1;
      }
    }
  }
  return map;
}



